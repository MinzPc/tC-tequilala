local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent("tC-tequilala:bill:player")
AddEventHandler("tC-tequilala:bill:player", function(playerId, amount)
        local biller = QBCore.Functions.GetPlayer(source)
        local billed = QBCore.Functions.GetPlayer(tonumber(playerId))
        local amount = tonumber(amount)
        if biller.PlayerData.job.name == 'tequilala' then
            if billed ~= nil then
                if biller.PlayerData.citizenid ~= billed.PlayerData.citizenid then
                    if amount and amount > 0 then
                        exports.oxmysql:insert('INSERT INTO phone_invoices (citizenid, amount, society, sender, sendercitizenid) VALUES (@citizenid, @amount, @society, @sender, @sendercitizenid)', {
                            ['@citizenid'] = billed.PlayerData.citizenid,
                            ['@amount'] = amount,
                            ['@society'] = biller.PlayerData.job.name,
                            ['@sender'] = biller.PlayerData.charinfo.firstname,
                            ['@sendercitizenid'] = biller.PlayerData.citizenid
                        })
                        TriggerClientEvent('qb-phone_new:RefreshPhone', billed.PlayerData.source)
                        TriggerClientEvent('QBCore:Notify', source, 'Hóa đơn được gửi thành công', 'success')
                        TriggerClientEvent('QBCore:Notify', billed.PlayerData.source, 'Hóa đơn mới nhận được')
                    else
                        TriggerClientEvent('QBCore:Notify', source, 'Phải là một số tiền hợp lệ trên 0', 'error')
                    end
                else
                    TriggerClientEvent('QBCore:Notify', source, 'Bạn không thể tự lập hóa đơn', 'error')
                end
            else
                TriggerClientEvent('QBCore:Notify', source, 'Người chơi không trực tuyến', 'error')
            end
        else
            TriggerClientEvent('QBCore:Notify', source, 'Không truy cập', 'error')
        end
end)
