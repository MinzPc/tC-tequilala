Config = {}

Config.Items = {
    label = "Tequi-la-la Shop",
    slots = 5,
    items = {
        [1] = {
            name = "tequilaa",
            price = 400,
            amount = 40,
            info = {},
            type = "item",
            slot = 1,
        },
        [2] = {
            name = "tequilab",
            price = 350,
            amount = 40,
            info = {},
            type = "item",
            slot = 2,
        },
        [3] = {
            name = "tequilac",
            price = 250,
            amount = 40,
            info = {},
            type = "item",
            slot = 3,
        },
        [4] = {
            name = "tequilad",
            price = 100,
            amount = 40,
            info = {},
            type = "item",
            slot = 4,
        },
        [5] = {
            name = "sandwich",
            price = 50,
            amount = 40,
            info = {},
            type = "item",
            slot = 5,
        },
    }
}

Config.vitribossmenu = {
	["boss"] = vector3(-571.85, 286.04, 79.18),
}

Config.Locations = {
    ["carspawn"] = {
        label = "Car Spawn",
        coords = {x =-574.33, y =268.94, z =82.45, h =85.29},
    },
}

Config.Vehicles = {
    ["faggio"] = "Xe Faggio Xịn Xò",
}
