# tC-tequilala



## Thêm điều này vào chia sẻ.lua trong QB-Core

### Job

```
["tequilala"] = {
		label = "Tequi-la-la",
		defaultDuty = true,
		grades = {
            ['0'] = {
                name = "DJ",
                payment = 50
            },
			['1'] = {
                name = "Bartender",
                payment = 75
            },
			['2'] = {
                name = "Bouncer",
                payment = 100
            },
			['3'] = {
                name = "Manager",
                payment = 125
            },
			['4'] = {
                name = "Owner",
				isboss = true,
                payment = 150
            },
        },
	},

``` 

## Thêm cái này vào QB-Bossmenu Config.lua

```
['tequilala'] = vector3(-568.577, 291.09, 79.18)
```
